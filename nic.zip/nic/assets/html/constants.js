const host = 'http://128.199.164.250/appiyo/';
const publicKey = 'MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAJ+GJdSSEeaNFBLqyfM3DIOgQgWCwJ0INfeZZV7ITsLeuA7Yd02rrkYGIix1IWvoebWVmzhncUepYxHwK1ARCdUCAwEAAQ==';
const apiVersions = {
    login: 'v3/',
    api: 'v2/'
}