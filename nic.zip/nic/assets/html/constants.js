const host = 'http://178.128.125.44/appiyo/';
const publicKey = 'MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAJ+GJdSSEeaNFBLqyfM3DIOgQgWCwJ0INfeZZV7ITsLeuA7Yd02rrkYGIix1IWvoebWVmzhncUepYxHwK1ARCdUCAwEAAQ==';
const apiVersions = {
    login: 'v3/',
    api: 'v2/'
}